-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 21 May 2019, 00:39:03
-- Sunucu sürümü: 5.7.23
-- PHP Sürümü: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `bildirgepuanlama`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bildirge`
--

DROP TABLE IF EXISTS `bildirge`;
CREATE TABLE IF NOT EXISTS `bildirge` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Baslik` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `Metin` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `Anahtar` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `bildirge`
--

INSERT INTO `bildirge` (`Id`, `Baslik`, `Metin`, `Anahtar`) VALUES
(1, 'Yapay Zeka', 'yapay zeka insanligin sonu olacak', 'yapay');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hakem`
--

DROP TABLE IF EXISTS `hakem`;
CREATE TABLE IF NOT EXISTS `hakem` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `KullaniciAd` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `Parola` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `Anahtar` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `hakem`
--

INSERT INTO `hakem` (`Id`, `KullaniciAd`, `Parola`, `Anahtar`) VALUES
(1, 'serdar', '123', 'felsefe');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kabulred`
--

DROP TABLE IF EXISTS `kabulred`;
CREATE TABLE IF NOT EXISTS `kabulred` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BildirgeId` int(11) NOT NULL,
  `Durum` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `puan`
--

DROP TABLE IF EXISTS `puan`;
CREATE TABLE IF NOT EXISTS `puan` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BildirgeId` int(11) NOT NULL,
  `HakemId` int(11) NOT NULL,
  `Puan` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `puan`
--

INSERT INTO `puan` (`Id`, `BildirgeId`, `HakemId`, `Puan`) VALUES
(1, 1, 0, 5);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
