package zhuoqiu;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class Qiudai {
	public int size=48;
	public int x;
	public int y;

	public Qiudai(int x, int y) {
		this.x = x;
		this.y = y;
	}
}