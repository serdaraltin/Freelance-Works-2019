package eminijava.ast;

import eminijava.lexer.JSymbol;

public abstract class ClassDecl extends Tree {

	public ClassDecl(JSymbol jsymbol) {
		super(jsymbol);
	}

}
