package eminijava.ast;

import eminijava.lexer.JSymbol;

public abstract class Type extends Tree {

	public Type(JSymbol jsymbol) {
		super(jsymbol);
	}

}
