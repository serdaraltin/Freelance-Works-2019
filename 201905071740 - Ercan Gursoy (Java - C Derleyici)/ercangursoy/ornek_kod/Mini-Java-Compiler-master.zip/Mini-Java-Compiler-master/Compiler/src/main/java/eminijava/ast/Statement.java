package eminijava.ast;

import eminijava.lexer.JSymbol;

public abstract class Statement extends Tree {

	public Statement(JSymbol jsymbol) {
		super(jsymbol);
		// TODO Auto-generated constructor stub
	}

	// @Override
	// public <R> R accept(Visitor<R> v) {
	// return v.visit(this);
	// }

}