package sysdep;

public enum RegisterClass {
    AX, BX, CX, DX, SI, DI, SP, BP, st, stn;
}
