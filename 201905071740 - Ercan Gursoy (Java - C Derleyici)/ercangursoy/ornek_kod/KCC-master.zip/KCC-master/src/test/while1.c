
int
main(int argc, char **argv)
{
    while (0) {
        puts("NG");
        return 1;
    }
    puts("OK");
    return 0;
}

int puts(char * i){
    return i;
}
