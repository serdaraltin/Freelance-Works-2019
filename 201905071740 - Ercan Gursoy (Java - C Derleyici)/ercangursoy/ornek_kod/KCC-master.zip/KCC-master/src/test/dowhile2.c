

int
main(int argc, char **argv)
{
    do {

        return 0;
    }
    while (1);

    return 1;
}
