

int
main(int argc, char **argv)
{
    while (1) {
        break;
        puts("NG");
    }
    puts("OK");

    return 0;
}

int puts(char * i){
    return i;
}