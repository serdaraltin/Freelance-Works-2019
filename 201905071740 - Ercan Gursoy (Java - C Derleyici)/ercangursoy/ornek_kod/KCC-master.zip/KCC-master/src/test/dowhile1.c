

int
main(int argc, char **argv)
{
    int i;
    do {
        i = i + 1;
    }
    while (0);
    return 0;
}
