struct a {
    int x;
};

int main(int argc, char **argv)
{
    struct a s;
    s.x = 1;
    return s.nosuchmember;
}
