import src1;
int main(int argc, char **argv) { return f(2); }
