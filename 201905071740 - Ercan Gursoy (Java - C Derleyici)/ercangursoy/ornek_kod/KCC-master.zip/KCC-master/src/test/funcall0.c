int 
main(int argc, char **argv)
{
    return f();
}

int
f()
{
    return 0;
}
