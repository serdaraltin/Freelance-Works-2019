

int
main(int argc, char **argv)
{
    if (2) {  }
    return 0;
}
