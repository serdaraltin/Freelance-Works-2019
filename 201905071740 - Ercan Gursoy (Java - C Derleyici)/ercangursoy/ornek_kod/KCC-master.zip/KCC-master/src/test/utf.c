

int main(int argc, char **argv) { puts("こんにちは世界"); }
int puts(char * i){
    return i;
}