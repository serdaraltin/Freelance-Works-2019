// indirect recursion
union a { union b x; };
union b { union c x; };
union c { union a x; };

int main(int argc, char **argv) { return 0; }
