

int
main(int argc, char **argv)
{
    int ary[4];
    int* ptr = ary;

    ptr[0] = 775;
    ptr[1] = 776;
    ptr[2] = 777;
    ptr[3] = 778;
    printf("%d;%d;%d;%d;", ary[0], ary[1], ary[2], ary[3]);
    printf("%d;%d;%d;%d;", ptr[0], ptr[1], ptr[2], ptr[3]);

    ary[0] = 775;
    ary[1] = 776;
    ary[2] = 777;
    ary[3] = 778;
    printf("%d;%d;%d;%d;", ary[0], ary[1], ary[2], ary[3]);
    printf("%d;%d;%d;%d;", ptr[0], ptr[1], ptr[2], ptr[3]);


    return 0;
}

static int
printf(char *s, ...)
{
    return 1;
}