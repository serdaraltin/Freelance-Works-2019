struct st { int x; };

int main(int argc, char **argv) {
    struct st s;
    return *s;
}
