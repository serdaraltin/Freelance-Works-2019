

int
main(int argc, char **argv)
{
    int i = 3;

    for (i = 3; i; i--) {

    }

    return 0;
}
