

int
main(int argc, char **argv)
{
    int i;

    for (i = 3; i; i--) {
        continue;

    }


    return 0;
}
