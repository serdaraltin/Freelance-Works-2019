import stdio;

int
main(int argc, char **argv)
{
    printf("Hell");
    printf("o, Wor");
    printf("ld!\n");
    return 0;
}
