union a {
    int x;
};

int main(int argc, char **argv)
{
    union a u;
    u.x = 1;
    return u.nosuchmember;
}
