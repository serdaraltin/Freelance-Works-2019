void f(void) { return 1; }
