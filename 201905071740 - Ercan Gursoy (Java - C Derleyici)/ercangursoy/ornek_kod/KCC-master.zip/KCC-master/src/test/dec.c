

int
main(int argc, char **argv)
{
    int i = 4;
    int j;

    --i;

    j = --i;

    i--;

    j = i--;



    return 0;
}
