

struct point {
    int x;
    int y;
};

int
main(int argc, char **argv)
{
    struct point pnt;

    pnt.x = 11;
    pnt.y = 22;
    printf("%d;%d\n", pnt.x, pnt.y);
    return 0;
}

static int
printf(char *s, ...)
{
    return 1;
}
