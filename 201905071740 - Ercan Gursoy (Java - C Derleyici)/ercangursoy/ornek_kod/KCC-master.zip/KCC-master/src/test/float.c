extern int printf(char * format, ...);

int
main(int argc, char **argv)
{
       float a = 1.5;
       a += 1.0;
       printf("%f\n", a);

       return 0;
}




