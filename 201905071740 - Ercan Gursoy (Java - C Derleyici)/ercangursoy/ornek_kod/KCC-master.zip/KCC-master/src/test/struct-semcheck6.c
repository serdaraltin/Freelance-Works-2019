struct a {
    int x;
};

int main(int argc, char **argv)
{
    struct a s;
    struct a *ptr = &s;
    ptr->x = 1;
    return ptr->nosuchmember;
}
