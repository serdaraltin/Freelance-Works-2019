

int
main(int argc, char **argv)
{
    int i;

    for (i = 1; i; i--) {
        break;

    }


    return 0;
}
