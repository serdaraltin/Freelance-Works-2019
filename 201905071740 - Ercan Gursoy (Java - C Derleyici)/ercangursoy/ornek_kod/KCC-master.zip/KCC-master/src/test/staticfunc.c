int
main(int argc, char **argv)
{
    return private_function();
}

static int
private_function(void)
{
    return 0;
}
