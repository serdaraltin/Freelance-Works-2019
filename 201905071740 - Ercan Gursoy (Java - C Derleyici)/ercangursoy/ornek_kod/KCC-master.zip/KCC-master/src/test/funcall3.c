int
main(int argc, char **argv)
{
    return f(998, 999, 0);
}

int
f(int i, int j, int k)
{
    return k;
}
