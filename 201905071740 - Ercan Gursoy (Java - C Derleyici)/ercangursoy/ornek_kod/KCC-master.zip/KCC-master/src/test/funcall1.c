int
main(int argc, char **argv)
{
    return f(0);
}

int
f(int i)
{
    return i;
}
