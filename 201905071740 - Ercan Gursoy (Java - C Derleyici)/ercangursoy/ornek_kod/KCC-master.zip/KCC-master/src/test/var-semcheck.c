import stdio;

static int n = f();

int
main(int argc, char** argv)
{
        printf("%d\n", n);
        return 0;
}

int f(void) { return 1; }
