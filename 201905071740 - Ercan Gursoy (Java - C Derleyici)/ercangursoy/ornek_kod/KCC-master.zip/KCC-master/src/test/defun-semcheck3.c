int f(void) { return; }
