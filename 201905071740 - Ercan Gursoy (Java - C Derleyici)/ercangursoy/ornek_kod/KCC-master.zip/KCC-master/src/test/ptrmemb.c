

struct s {
    int x;
    int y;
};

union u {
    int x;
    int y;
};

int
main(int argc, char **argv)
{
    struct s st;
    struct s* ptr = &st;
    union u uni;
    union u* uptr = &uni;

    ptr->x = 1;
    ptr->y = 2;
    printf("%d;%d", ptr->x, ptr->y);

    (*ptr).x = 3;
    (*ptr).y = 4;
    printf(";%d;%d", (*ptr).x, (*ptr).y);

    uptr->x = 5;
    printf(";%d", uptr->y);

    (*uptr).x = 6;
    printf(";%d", (*uptr).y);

    printf(";%d", f()->x);
    printf(";%d", f()->y);


    return 0;
}

static struct s ss;

struct s *
f(void)
{
    ss.x = 77;
    ss.y = 78;
    return &ss;
}

static int
printf(char *s, ...)
{
    return 1;
}