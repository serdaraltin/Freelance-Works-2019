union u { int x; };
typedef union u mytype;
mytype g(void) { return 1; }
