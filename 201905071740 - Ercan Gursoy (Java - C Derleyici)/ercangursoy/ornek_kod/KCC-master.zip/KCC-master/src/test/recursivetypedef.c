

typedef int t;
typedef t* t;
