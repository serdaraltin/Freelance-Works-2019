import stdio;

int
main(int argc, char **argv)
{
    printf("%s\n", "Hello, World!");
    return 0;
}
