struct st { int x; };
struct st f(void) { return; }
