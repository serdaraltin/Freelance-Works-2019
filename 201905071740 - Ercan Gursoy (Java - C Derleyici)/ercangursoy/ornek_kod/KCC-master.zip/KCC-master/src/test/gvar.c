

int global_int = 1;
char *global_string = "OK";

int
main(int argc, char **argv)
{

    global_int = 2;



    global_string = "NEW";






    return 0;
}
