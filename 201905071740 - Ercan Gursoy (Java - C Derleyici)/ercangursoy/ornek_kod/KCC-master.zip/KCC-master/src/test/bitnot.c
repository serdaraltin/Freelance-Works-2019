int
main(int argc, char **argv)
{
    int i = ~0;
    return ~(-1);
    return 0;
}
