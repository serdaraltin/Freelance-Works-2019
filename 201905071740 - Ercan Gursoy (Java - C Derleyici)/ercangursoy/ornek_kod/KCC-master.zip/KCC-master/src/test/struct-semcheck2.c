struct a {
    struct a x;
};

int main(int argc, char **argv) { return 0; }
