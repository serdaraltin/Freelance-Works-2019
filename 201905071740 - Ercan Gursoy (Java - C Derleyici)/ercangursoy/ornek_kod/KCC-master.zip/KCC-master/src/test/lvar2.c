

int
main(int argc, char **argv)
{
    int i;
    int j = 3;

    i = 1;

    i = 2;

    j = 4;

    i = 5;


    return 0;
}
