

const int RTLD_LAZY = 0x10;
const char* MSG = "msgstring";

int main(int argc, char** argv)
{
        int lazy =  RTLD_LAZY;

        char* msgs=  MSG;
         lazy =  RTLD_LAZY;

        return 0;
}
