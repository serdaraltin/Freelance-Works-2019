
int
main(int argc, char **argv)
{
    int a[5];

    a[0] = 1;
    a[1] = 3;
    a[2] = 5;
    a[3] = 7;
    a[4] = 9;
    return 0;
}
