import stdio;
import errno;

int
main(int argc, char **argv)
{
    printf("<<%s>>\n", sys_errlist[3]);
    printf("printf=%p\n", printf);
    return 0;
}
