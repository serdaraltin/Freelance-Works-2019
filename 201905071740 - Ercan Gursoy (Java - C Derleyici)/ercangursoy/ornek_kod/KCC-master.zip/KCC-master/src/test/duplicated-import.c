import stdio;
import string;

int
main(int argc, char **argv)
{
    puts("OK");
    return 0;
}
