int
main(void)
{
    int[4] a;
    a;
    return 0;
}
