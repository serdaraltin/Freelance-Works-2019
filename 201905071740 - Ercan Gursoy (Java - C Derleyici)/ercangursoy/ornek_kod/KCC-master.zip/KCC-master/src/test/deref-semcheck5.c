struct st { int x; };

int main(int argc, char **argv) {
    struct st s;
    struct st *ptr = &s;
    ptr->x = 0;
    return ptr->y;
}
