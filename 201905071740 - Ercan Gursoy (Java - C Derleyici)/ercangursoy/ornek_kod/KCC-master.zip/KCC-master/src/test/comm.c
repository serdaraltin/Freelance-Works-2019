
int global_int;
char *global_string;

int
main(int argc, char **argv)
{
    global_int = 1;

    global_int = 2;


    global_string = "OK";

    global_string = "NEW";


    return 0;
}
