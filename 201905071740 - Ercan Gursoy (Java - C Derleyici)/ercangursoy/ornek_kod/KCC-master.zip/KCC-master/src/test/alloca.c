import stdio;
import string;
import alloca;

int
main(void)
{
    char* p = alloca(32);
    strcpy(p, "Hello");
    printf("<<%s>>\n", p);
    return 0;
}
