import stdio;

int
main(int argc, char **argv)
{
    int i = 777;
    int* ptr = &i;

    long x = 666;
    long* lp = &x;

    printf("%d;%d\n", *(int*)ptr, *(int*)lp);

    return 0;
}
