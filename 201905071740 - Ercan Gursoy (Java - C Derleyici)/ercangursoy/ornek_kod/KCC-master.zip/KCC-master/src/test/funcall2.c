int
main(int argc, char **argv)
{
    return f(999, 0);
}

int
f(int i, int j)
{
    return j;
}
