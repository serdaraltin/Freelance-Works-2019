union un {
    int x;
};

int
main(void)
{
    union un u;
    u;
    return 0;
}
