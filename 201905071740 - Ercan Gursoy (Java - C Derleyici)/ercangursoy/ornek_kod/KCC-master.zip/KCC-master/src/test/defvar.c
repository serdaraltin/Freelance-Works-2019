
int main(void)
{
    int x = 7, y = 2, z;
    z = 3;
    x = 1;
    return 0;
}
