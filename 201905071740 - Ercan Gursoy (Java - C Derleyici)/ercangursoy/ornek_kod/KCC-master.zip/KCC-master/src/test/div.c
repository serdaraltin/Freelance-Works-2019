

int
main(int argc, char **argv)
{
    int a[4];

    a[3] = 1 / 1;
    a[2] = 2 / 1;
    a[1] = 4 / 2;
    a[1] = 5 / 2;

    a[0] = 16;




    return 0;
}
