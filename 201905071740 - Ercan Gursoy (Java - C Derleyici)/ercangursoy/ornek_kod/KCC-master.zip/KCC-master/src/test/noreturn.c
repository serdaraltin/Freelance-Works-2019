

int
main(int argc, char **argv)
{
    f();
    return 0;
}

static void
f(void)
{
}
