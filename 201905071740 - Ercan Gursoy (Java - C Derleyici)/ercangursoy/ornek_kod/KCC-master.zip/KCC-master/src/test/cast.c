
int
main(int argc, char **argv)
{
    short n = 5000;
    char a = 1;
    char b = -1;
    short c = 1;
    short d = -1;

    long g =  ((long)n * (long)n);
    a = (int)a;
    a = (long)a;
    b =  (int)b;
    b =  (long)b;
    c =  (int)c;
    c =  (long)c;
    d =  (int)d;
    d =  (long)d;

    return 0;
}
