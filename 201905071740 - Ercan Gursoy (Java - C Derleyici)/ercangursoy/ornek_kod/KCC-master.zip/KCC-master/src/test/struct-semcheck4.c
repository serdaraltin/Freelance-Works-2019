// indirect recursion
struct a { struct b x; };
struct b { struct c x; };
struct c { struct a x; };

int main(int argc, char **argv) { return 0; }
