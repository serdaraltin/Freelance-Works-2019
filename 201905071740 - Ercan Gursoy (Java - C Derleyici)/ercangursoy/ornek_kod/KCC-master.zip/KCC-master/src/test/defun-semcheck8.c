int[2] f(void) { return 1; }
