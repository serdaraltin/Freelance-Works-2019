struct s { int x; };
typedef struct s mytype;
mytype f(void) { return 1; }
