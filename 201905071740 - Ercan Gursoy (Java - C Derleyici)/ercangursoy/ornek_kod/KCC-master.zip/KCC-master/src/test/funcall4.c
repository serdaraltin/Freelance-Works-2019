int f(int i, int j) { return j; }

int
main(int argc, char **argv)
{
    return f(2, 1) - 1;
}
