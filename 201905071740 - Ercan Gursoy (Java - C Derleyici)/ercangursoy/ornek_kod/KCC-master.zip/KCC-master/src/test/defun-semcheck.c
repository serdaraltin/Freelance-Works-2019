void f(int a, int a) {}
