union a {
    int x;
    void y;
};

int main(int argc, char **argv) { return 0; }
