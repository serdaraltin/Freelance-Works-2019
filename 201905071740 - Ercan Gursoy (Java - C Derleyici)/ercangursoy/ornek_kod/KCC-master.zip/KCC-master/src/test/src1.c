int f(int x) { return x * x; }
