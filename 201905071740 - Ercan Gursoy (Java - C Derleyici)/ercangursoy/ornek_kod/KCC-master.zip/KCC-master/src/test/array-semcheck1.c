int main(int argc, char **argv) { void[1] ary; return 0; }
