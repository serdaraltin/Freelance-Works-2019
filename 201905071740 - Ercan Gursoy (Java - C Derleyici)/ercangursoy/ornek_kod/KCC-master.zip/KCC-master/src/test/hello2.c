import stdio;

int
main(int argc, char **argv)
{
    puts("Hello, World!");
    return 0;
}
