

struct s {};

int
main(int argc, char **argv)
{
    struct s st;
    struct s* p = &st;


    return 0;
}
