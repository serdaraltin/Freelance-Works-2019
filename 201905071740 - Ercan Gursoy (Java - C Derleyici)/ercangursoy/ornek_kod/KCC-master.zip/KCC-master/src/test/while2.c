

int
main(int argc, char **argv)
{
    while (1) {
        puts("OK");
        return 0;
    }
    puts("NG");
    return 1;
}

int puts(char * i){
    return i;
}