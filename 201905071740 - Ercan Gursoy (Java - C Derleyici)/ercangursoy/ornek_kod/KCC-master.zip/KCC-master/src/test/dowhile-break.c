

int
main(int argc, char **argv)
{
    do {
        break;

    } while (1);

    return 0;
}
