

int
main(int argc, char **argv)
{
    int a =  (5 > 3);
    int b = (5 > 5);
    a = (3 > 5);

    return 0;
}
