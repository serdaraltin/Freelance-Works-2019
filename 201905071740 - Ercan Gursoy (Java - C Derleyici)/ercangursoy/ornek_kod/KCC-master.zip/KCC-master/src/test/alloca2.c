import stdio;
import string;
import alloca;

int
main(int argc, char **argv)
{
    fa();
    puts("");
    return 0;
}

static int
fa(void)
{
    int[10] junk;
    int x = 4 * 4 - 13;
    char* s = alloca(10);

    fb();
    strcpy(s, ";%d");
    printf(s, 14 + x);
}

static int
fb(void)
{
    int[10] junk;
    int x = (61 - 1) / 4;
    char* s = alloca(15);
    x += 4;

    fc();
    strcpy(s, ";%d");
    printf(s, x - 2);
}

static int
fc(void)
{
    int[10] junk;
    int x = 4 * 4;
    char* s = alloca(20);
    x--;

    fd();
    strcpy(s, ";%d");
    printf(s, x + 2);
}

static int
fd(void)
{
    int[10] junk;
    int x = 88 / 4;
    char* s = alloca(25);

    strcpy(s, "%d");
    printf(s, -5 + x);
}
