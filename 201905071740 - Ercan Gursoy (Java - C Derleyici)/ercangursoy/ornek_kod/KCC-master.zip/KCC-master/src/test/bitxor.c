int
main(int argc, char **argv)
{
    int i =  0^0,
     j = 0^1, k = 0^2, l = 1^2, u = 2^2, p = 2^4;
    return 0;
}