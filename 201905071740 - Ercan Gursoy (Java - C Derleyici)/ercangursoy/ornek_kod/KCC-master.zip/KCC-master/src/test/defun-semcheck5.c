union u { int x; };
union u f(void) { return 1; }
