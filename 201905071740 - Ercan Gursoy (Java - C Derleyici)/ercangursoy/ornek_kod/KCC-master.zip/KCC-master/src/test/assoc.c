import stdio;

int
main(int argc, char **argv)
{
    printf("%d\n", 5 - 1 - 1);
    return 0;
}
