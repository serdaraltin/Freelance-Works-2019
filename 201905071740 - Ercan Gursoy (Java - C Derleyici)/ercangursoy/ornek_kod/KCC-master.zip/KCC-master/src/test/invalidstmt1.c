struct st {
    int x;
};

int
main(void)
{
    struct st s;
    s;
    return 0;
}
