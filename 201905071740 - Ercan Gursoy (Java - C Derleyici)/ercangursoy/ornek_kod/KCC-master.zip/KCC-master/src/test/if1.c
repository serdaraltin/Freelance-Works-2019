char *result;

int
main(int argc, char **argv)
{
    if (2) {
        result = ("OK");
    }
    else {
        result = ("NG");
    }
    return 0;
}
