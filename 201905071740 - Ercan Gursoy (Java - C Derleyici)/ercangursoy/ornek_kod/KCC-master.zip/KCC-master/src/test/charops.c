
int
main(int argc, char **argv)
{
    char i = 1;
    
    i <<= 1;
    i <<= 5;
    i <<= 1;
    i <<= 1;
    return 0;
}
