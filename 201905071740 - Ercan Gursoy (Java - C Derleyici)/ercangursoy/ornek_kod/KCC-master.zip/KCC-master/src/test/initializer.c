

int
main(int argc, char **argv)
{
    int i = 4;
    int x = i * 5 * i;
    int y = (x - x) * x;

    char *s = "local";


    return 0;
}
