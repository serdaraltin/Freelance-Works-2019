package type;

public class TypeRef {

    public TypeRef(){

    }

    public int hashCode() {
        return toString().hashCode();
    }
}
