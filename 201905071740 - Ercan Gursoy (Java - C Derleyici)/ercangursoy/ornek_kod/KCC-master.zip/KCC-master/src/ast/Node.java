package ast;

abstract public class Node {

}
