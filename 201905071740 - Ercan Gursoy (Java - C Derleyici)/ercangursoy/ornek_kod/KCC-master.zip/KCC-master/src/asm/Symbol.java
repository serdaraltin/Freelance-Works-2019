package asm;

public interface Symbol extends Literal{
    public String name();
    public String toString();
}
