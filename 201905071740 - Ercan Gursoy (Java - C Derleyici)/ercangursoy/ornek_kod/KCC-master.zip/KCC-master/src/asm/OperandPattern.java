package asm;

public interface OperandPattern {
    public boolean match(Operand operand);
}
