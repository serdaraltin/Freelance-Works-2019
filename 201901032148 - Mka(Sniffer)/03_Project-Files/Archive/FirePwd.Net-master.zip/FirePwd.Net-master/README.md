-----------------
-- FirePwd.Net --
-----------------

FirePwd.Net is an open source tool wrote in C# to decrypt Mozilla stored password.

Based on the work of lclevy (https://github.com/lclevy/firepwd) and his article published on french magazine MISC september/october 2013.


This code is released under GPL license.
Except System.Data.SQLite package wrote by mistachkin under domain public. (http://system.data.sqlite.org)


FirePwd.Net v0.1
Usage :
	 -p to specify Master Password
	 -v to activate verbose mode
	 -f to specify path for files key3.db and signons.sqlite
	 -h show this help

Enjoy ;)                                                
