# BrowserPass
Retrieves passwords stored in browsers written in pure C#


Supported browsers:
* Chrome
* Internet Explorer 10+ / Edge
* FireFox
