Joseph Mulray
SE311
January 23 2018
Assignment 1 : KWIC


UML Diagram:
Included a png image as well as a pdf version of UML for assignment.
PNG:
	UML.png
PDF:
	UML-A1.pdf


Makefile included just run make within src/ folder, will execute and run program
Main driver class is MasterControl.java, gathers input and output settings and then build the rest of the program using the other classes. Also put a copy of this README in there.

Included test file <test>. You can read from them giving input <filename> if it is in the same directory, or if you want to create directory and file should work fine.

# Makefile Commands:

> view:
  view source code
> clean:
  remove .class files
> run:
  run and execute program

