Joseph Mulray
SE311
January 23 2018
Assignment 1 : KWIC


Makefile included just run make within src/ folder, will execute and run program
Main driver class is MasterControl.java, gathers input and output settings and then build the rest of the program using the other classes.

Included test file <test>. You can read from them giving input <filename> if it is in the same directory, or if you want to create directory and file should work fine.

# Makefile Commands:

> view:
  view source code
> clean:
  remove .class files
> run:
  run and execute program

