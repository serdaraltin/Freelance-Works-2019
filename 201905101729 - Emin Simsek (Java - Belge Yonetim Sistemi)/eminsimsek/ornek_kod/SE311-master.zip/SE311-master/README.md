# SE311

##### A1: KWIC
##### A2: KWIC Pipe and Filter
##### A3: KWIC Interactive
##### A4: Simple Calculator

##### L1: Pipe and Filter
##### L2: Implicit Invocation
##### L3: Simple File System
##### L4: Client Server
