public interface Visitor{

	void visit(FileSystem system);

}