# Pushdown Automata
## Deterministic PDA C# Console Application:

Example : Defining PDA for L = {a^nb^n | n>0}

![Pda](https://github.com/oguzhanszr/pushdown-automata/blob/master/images/e.PNG)

Test aaabbb string (n=3) <br>
![Test1](https://github.com/oguzhanszr/pushdown-automata/blob/master/images/d.PNG)

Test aaabbbb string <br>
![Test2](https://github.com/oguzhanszr/pushdown-automata/blob/master/images/f.PNG)
