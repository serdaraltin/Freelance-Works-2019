Discrete Cosine Transform
Author: Andrew Chalmers, 2014
    
This calculates the DCT at different frequencies in two dimensions. 
Some packages don't allow you to specify the basis (u,v), but
instead sum across the frequencies giving you the final result.

Useful applications for specifying a certain basis can be for educational
purposes (visualising the basis functions), or if you need to split the 
bases into a dictionary for learning.

I've left this unoptimised for clarity. 

Resources:
Image and video processing: From Mars to Hollywood with a stop at the hospital,
lecture 10. By Guillermo Sapiro from Duke University
