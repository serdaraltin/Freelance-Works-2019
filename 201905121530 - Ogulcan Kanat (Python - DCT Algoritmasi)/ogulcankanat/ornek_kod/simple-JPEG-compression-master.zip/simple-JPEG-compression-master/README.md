# simple-JPEG-compression

simple example of encoding a grayscale image by outputting two text files that includes the encoding, [height,width,box_size]
of the image to be used by the decoder to recreate the image
