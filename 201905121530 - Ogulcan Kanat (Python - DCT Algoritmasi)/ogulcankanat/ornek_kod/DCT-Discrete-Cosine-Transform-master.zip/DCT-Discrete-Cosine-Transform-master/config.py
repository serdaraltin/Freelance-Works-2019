imageToRead = "lena256.jpg"
#imageToRead = "lena256color.jpg"
#imageToRead = "lena64.jpg"
dtype='uint8'
