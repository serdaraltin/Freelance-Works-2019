# DCT-Discrete-Cosine-Transform-
Identify the frequency domain of an image. Aplly Discrete Cosine Transform(DCT ) and  Inverse Discrete Cosine Transform(IDCT) in image



## Dependencias
[OpenCV](https://docs.opencv.org/3.0-beta/index.html)
```
sudo apt-get install python-opencv
```


## Como usar

```sh
python main.py 
```

## Grupo
- Abraão Allysson
- Felipe Andrade
- Wellton Thyago
- Yuri Gouveia
