package atakancoskuner;

import java.util.concurrent.Semaphore;

public class Main {

    static class barrier {

        Semaphore semaphore = new Semaphore(1);
        int maxim = 1, count;
        int count_release = maxim;
        int[] A = new int[maxim];
        int[] B = new int[maxim];

        void init(int max) {

            this.maxim = max;
            count_release = maxim;
            System.out.println("maximum : " + maxim);
        }

        void barrier() throws InterruptedException {
            System.out.println("aa");
            semaphore.acquire();
            System.out.println(count + " semaphore acquire");
            count++;

            if (count != maxim) {
                semaphore.release();
                System.out.println(count + " semaphore release");

                while (count != maxim) {

                    Thread.sleep(1000);
                }
                semaphore.acquire();
            }
            count_release--;
            if (count_release == 0) {
                count = 0;
                count_release = maxim;
                semaphore.release();
                System.out.println(count + " semaphore release");
            }
        }
    }

    public static void main(String[] args) {
        barrier bar = new barrier();
        bar.init(3);
    }
}
